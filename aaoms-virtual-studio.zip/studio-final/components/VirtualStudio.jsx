'use client'
import { useState, useRef, useEffect, useCallback } from 'react'

const COLORS = [
  { id: 'navy', name: 'Navy', hex: '#1e3a5f' },
  { id: 'wine', name: 'Wine', hex: '#722f37' },
  { id: 'maroon', name: 'Maroon', hex: '#800020' },
  { id: 'black', name: 'Black', hex: '#1a1a1a' },
  { id: 'forest', name: 'Forest', hex: '#225537' },
  { id: 'heather', name: 'Heather', hex: '#8c9196' },
  { id: 'mauve', name: 'Mauve', hex: '#915f6d' },
]

const STYLES = [
  { id: 'vneck', name: 'V-Neck' },
  { id: 'mandarin', name: 'Mandarin' },
  { id: 'jogger', name: 'Jogger Set' },
  { id: 'stretch', name: 'Stretch Premium' },
]

export default function VirtualStudio() {
  const canvasRef = useRef(null)
  const [step, setStep] = useState(1)
  const [photoImg, setPhotoImg] = useState(null)
  const [scrubColor, setScrubColor] = useState('navy')
  const [scrubStyle, setScrubStyle] = useState('vneck')
  const [scrubScale, setScrubScale] = useState(0.85)
  const [scrubPos, setScrubPos] = useState({ x: 300, y: 280 })
  const [logoImg, setLogoImg] = useState(null)
  const [logoScale, setLogoScale] = useState(0.35)
  const [logoPos, setLogoPos] = useState({ x: 340, y: 220 })
  const [text, setText] = useState('')
  const [textSize, setTextSize] = useState(22)
  const [textColor, setTextColor] = useState('#ffffff')
  const [textPos, setTextPos] = useState({ x: 300, y: 260 })
  const [height, setHeight] = useState('')
  const [activeLayer, setActiveLayer] = useState('scrub')
  const [dragging, setDragging] = useState(false)
  const dragOffset = useRef({ x: 0, y: 0 })

  const draw = useCallback(() => {
    const canvas = canvasRef.current
    if (!canvas || !photoImg) return
    const ctx = canvas.getContext('2d')
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    ctx.drawImage(photoImg, 0, 0, canvas.width, canvas.height)

    const colorObj = COLORS.find(c => c.id === scrubColor) || COLORS[0]
    const sw = 220 * scrubScale
    const sh = 320 * scrubScale
    ctx.save()
    ctx.globalAlpha = 0.82
    ctx.fillStyle = colorObj.hex
    roundRect(ctx, scrubPos.x - sw/2, scrubPos.y - sh/2, sw, sh, 18)
    ctx.fill()
    ctx.globalCompositeOperation = 'destination-out'
    ctx.beginPath()
    ctx.moveTo(scrubPos.x - 28*scrubScale, scrubPos.y - sh/2 + 8)
    ctx.lineTo(scrubPos.x, scrubPos.y - sh/2 + 55*scrubScale)
    ctx.lineTo(scrubPos.x + 28*scrubScale, scrubPos.y - sh/2 + 8)
    ctx.closePath()
    ctx.fill()
    ctx.restore()

    if (logoImg) {
      const lw = 80 * logoScale
      const lh = (logoImg.height / logoImg.width) * lw
      ctx.drawImage(logoImg, logoPos.x - lw/2, logoPos.y - lh/2, lw, lh)
    }

    if (text) {
      ctx.save()
      ctx.font = `600 ${textSize}px Inter, system-ui, sans-serif`
      ctx.fillStyle = textColor
      ctx.textAlign = 'center'
      ctx.textBaseline = 'middle'
      ctx.shadowColor = 'rgba(0,0,0,0.5)'
      ctx.shadowBlur = 3
      ctx.fillText(text, textPos.x, textPos.y)
      ctx.restore()
    }
  }, [photoImg, scrubColor, scrubScale, scrubPos, logoImg, logoScale, logoPos, text, textSize, textColor, textPos])

  useEffect(() => { draw() }, [draw])

  function roundRect(ctx, x, y, w, h, r) {
    ctx.beginPath()
    ctx.moveTo(x + r, y)
    ctx.arcTo(x + w, y, x + w, y + h, r)
    ctx.arcTo(x + w, y + h, x, y + h, r)
    ctx.arcTo(x, y + h, x, y, r)
    ctx.arcTo(x, y, x + w, y, r)
    ctx.closePath()
  }

  function loadPhoto(file) {
    const reader = new FileReader()
    reader.onload = e => {
      const img = new Image()
      img.onload = () => {
        const canvas = canvasRef.current
        const maxW = 600, maxH = 800
        const ratio = Math.min(maxW / img.width, maxH / img.height)
        canvas.width = Math.round(img.width * ratio)
        canvas.height = Math.round(img.height * ratio)
        setPhotoImg(img)
        setScrubPos({ x: canvas.width * 0.5, y: canvas.height * 0.38 })
        setLogoPos({ x: canvas.width * 0.58, y: canvas.height * 0.30 })
        setTextPos({ x: canvas.width * 0.5, y: canvas.height * 0.34 })
      }
      img.src = e.target.result
    }
    reader.readAsDataURL(file)
  }

  function loadLogo(file) {
    const reader = new FileReader()
    reader.onload = e => {
      const img = new Image()
      img.onload = () => setLogoImg(img)
      img.src = e.target.result
    }
    reader.readAsDataURL(file)
  }

  function getPos(e) {
    const canvas = canvasRef.current
    const rect = canvas.getBoundingClientRect()
    const scaleX = canvas.width / rect.width
    const scaleY = canvas.height / rect.height
    const clientX = e.touches ? e.touches[0].clientX : e.clientX
    const clientY = e.touches ? e.touches[0].clientY : e.clientY
    return { x: (clientX - rect.left) * scaleX, y: (clientY - rect.top) * scaleY }
  }

  function onPointerDown(e) {
    if (step < 2 || !photoImg) return
    const pos = getPos(e)
    // simple hit test priority: logo > text > scrub
    let hit = null
    if (logoImg) {
      const lw = 80 * logoScale
      if (Math.abs(pos.x - logoPos.x) < lw/2 + 12 && Math.abs(pos.y - logoPos.y) < 40) hit = 'logo'
    }
    if (!hit && text) {
      if (Math.abs(pos.x - textPos.x) < 80 && Math.abs(pos.y - textPos.y) < 20) hit = 'text'
    }
    if (!hit) {
      const sw = 220 * scrubScale
      const sh = 320 * scrubScale
      if (Math.abs(pos.x - scrubPos.x) < sw/2 && Math.abs(pos.y - scrubPos.y) < sh/2) hit = 'scrub'
    }
    if (hit) {
      setActiveLayer(hit)
      setDragging(true)
      if (hit === 'scrub') dragOffset.current = { x: pos.x - scrubPos.x, y: pos.y - scrubPos.y }
      if (hit === 'logo') dragOffset.current = { x: pos.x - logoPos.x, y: pos.y - logoPos.y }
      if (hit === 'text') dragOffset.current = { x: pos.x - textPos.x, y: pos.y - textPos.y }
      e.currentTarget.setPointerCapture(e.pointerId)
    }
  }

  function onPointerMove(e) {
    if (!dragging) return
    const pos = getPos(e)
    if (activeLayer === 'scrub') setScrubPos({ x: pos.x - dragOffset.current.x, y: pos.y - dragOffset.current.y })
    if (activeLayer === 'logo') setLogoPos({ x: pos.x - dragOffset.current.x, y: pos.y - dragOffset.current.y })
    if (activeLayer === 'text') setTextPos({ x: pos.x - dragOffset.current.x, y: pos.y - dragOffset.current.y })
  }

  function onPointerUp() { setDragging(false) }

  function download() {
    const canvas = canvasRef.current
    const link = document.createElement('a')
    link.download = 'aaoms-studio-look.png'
    link.href = canvas.toDataURL('image/png')
    link.click()
  }

  function orderWhatsApp() {
    const colorName = COLORS.find(c => c.id === scrubColor)?.name || scrubColor
    let msg = `Hi aaoms! I designed a look in the Virtual Studio.%0A%0A`
    msg += `• Style: ${scrubStyle}%0A• Colour: ${colorName}%0A`
    if (height) msg += `• Height: ${height} cm%0A`
    if (text) msg += `• Embroidery Name: ${text}%0A`
    if (logoImg) msg += `• Logo: Yes (I will send the logo)%0A`
    msg += `%0APlease help me place the order.`
    window.open(`https://wa.me/9779803840868?text=${msg}`, '_blank')
  }

  const sizeSuggest = (() => {
    const h = parseInt(height)
    if (!h || h < 140 || h > 210) return null
    if (h < 155) return 'XS / S'
    if (h < 165) return 'S / M'
    if (h < 175) return 'M / L'
    if (h < 185) return 'L / XL'
    return 'XL / XXL'
  })()

  return (
    <div style={{ minHeight: '100vh', background: '#0f0f12', color: '#f5f5f7', fontFamily: 'Inter, system-ui, sans-serif' }}>
      <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '14px 24px', borderBottom: '1px solid #2a2a35', position: 'sticky', top: 0, background: 'rgba(15,15,18,0.92)', backdropFilter: 'blur(12px)', zIndex: 50 }}>
        <div style={{ fontWeight: 700, fontSize: '1.3rem' }}>aaoms <span style={{ color: '#e85d04' }}>Studio</span></div>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          {[1,2,3,4].map(n => (
            <div key={n} onClick={() => photoImg && setStep(n)} style={{
              padding: '6px 14px', borderRadius: 999, fontSize: '0.8rem', fontWeight: 500, cursor: 'pointer',
              background: step === n ? '#e85d04' : step > n ? '#1e3a2f' : '#1a1a21',
              border: `1px solid ${step === n ? '#e85d04' : '#2a2a35'}`,
              color: step === n ? '#fff' : step > n ? '#7dcea0' : '#9a9aa8'
            }}>
              {n === 1 && '1. Photo'}{n === 2 && '2. Scrub'}{n === 3 && '3. Embroidery'}{n === 4 && '4. Finish'}
            </div>
          ))}
        </div>
      </header>

      <div style={{ maxWidth: 1280, margin: '0 auto', padding: '24px 16px 80px', display: 'grid', gridTemplateColumns: '1fr 340px', gap: 28 }}>
        <div style={{ background: '#1a1a21', border: '1px solid #2a2a35', borderRadius: 16, minHeight: 520, display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative' }}>
          {!photoImg && (
            <div style={{ textAlign: 'center', color: '#9a9aa8' }}>
              <h3 style={{ color: '#f5f5f7', marginBottom: 8 }}>Upload your photo to start</h3>
              <p>Full body or upper body works best</p>
            </div>
          )}
          <canvas
            ref={canvasRef}
            width={600}
            height={800}
            style={{ maxWidth: '100%', maxHeight: '70vh', cursor: dragging ? 'grabbing' : 'grab', touchAction: 'none', display: photoImg ? 'block' : 'none' }}
            onPointerDown={onPointerDown}
            onPointerMove={onPointerMove}
            onPointerUp={onPointerUp}
            onPointerCancel={onPointerUp}
          />
        </div>

        <div style={{ background: '#1a1a21', border: '1px solid #2a2a35', borderRadius: 16, padding: 20, height: 'fit-content', position: 'sticky', top: 80 }}>
          {step === 1 && (
            <>
              <h2 style={{ fontSize: '1.05rem', marginBottom: 16 }}>Your Photo</h2>
              <label style={{ display: 'block', border: '2px dashed #2a2a35', borderRadius: 12, padding: '28px 16px', textAlign: 'center', cursor: 'pointer', color: '#9a9aa8' }}>
                📷 Click or drop your photo
                <input type="file" accept="image/*" hidden onChange={e => e.target.files[0] && loadPhoto(e.target.files[0])} />
              </label>
              <div style={{ marginTop: 16 }}>
                <label style={{ fontSize: '0.78rem', color: '#9a9aa8', textTransform: 'uppercase' }}>Height (cm)</label>
                <input type="number" value={height} onChange={e => setHeight(e.target.value)} placeholder="e.g. 165" style={{ width: '100%', padding: '10px 12px', borderRadius: 8, border: '1px solid #2a2a35', background: '#0f0f12', color: '#f5f5f7', marginTop: 6 }} />
                {sizeSuggest && <div style={{ marginTop: 10, padding: 12, background: 'rgba(232,93,4,0.1)', border: '1px solid rgba(232,93,4,0.3)', borderRadius: 10, fontSize: '0.9rem' }}>Suggested size: <strong>{sizeSuggest}</strong></div>}
              </div>
              <button disabled={!photoImg} onClick={() => setStep(2)} style={{ width: '100%', marginTop: 16, padding: '12px', borderRadius: 10, border: 'none', background: photoImg ? '#e85d04' : '#333', color: '#fff', fontWeight: 600, cursor: photoImg ? 'pointer' : 'not-allowed' }}>Next: Choose Scrub →</button>
            </>
          )}

          {step === 2 && (
            <>
              <h2 style={{ fontSize: '1.05rem', marginBottom: 16 }}>Choose Your Scrub</h2>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 16 }}>
                {STYLES.map(s => (
                  <div key={s.id} onClick={() => setScrubStyle(s.id)} style={{ padding: 12, borderRadius: 10, border: `1px solid ${scrubStyle === s.id ? '#e85d04' : '#2a2a35'}`, background: scrubStyle === s.id ? 'rgba(232,93,4,0.08)' : 'transparent', textAlign: 'center', cursor: 'pointer', fontSize: '0.82rem' }}>{s.name}</div>
                ))}
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 8, marginBottom: 16 }}>
                {COLORS.map(c => (
                  <div key={c.id} onClick={() => setScrubColor(c.id)} title={c.name} style={{ aspectRatio: 1, borderRadius: 10, background: c.hex, border: `2px solid ${scrubColor === c.id ? '#e85d04' : 'transparent'}`, cursor: 'pointer' }} />
                ))}
              </div>
              <label style={{ fontSize: '0.78rem', color: '#9a9aa8' }}>Scrub Size</label>
              <input type="range" min="30" max="180" value={scrubScale * 100} onChange={e => setScrubScale(e.target.value / 100)} style={{ width: '100%', margin: '8px 0' }} />
              <p style={{ fontSize: '0.78rem', color: '#9a9aa8' }}>Drag the scrub on the photo to position it.</p>
              <div style={{ display: 'flex', gap: 10, marginTop: 16 }}>
                <button onClick={() => setStep(1)} style={{ flex: 1, padding: 12, borderRadius: 10, border: '1px solid #2a2a35', background: 'transparent', color: '#f5f5f7', cursor: 'pointer' }}>← Back</button>
                <button onClick={() => setStep(3)} style={{ flex: 1, padding: 12, borderRadius: 10, border: 'none', background: '#e85d04', color: '#fff', fontWeight: 600, cursor: 'pointer' }}>Next →</button>
              </div>
            </>
          )}

          {step === 3 && (
            <>
              <h2 style={{ fontSize: '1.05rem', marginBottom: 16 }}>Embroidery</h2>
              <label style={{ display: 'block', border: '2px dashed #2a2a35', borderRadius: 12, padding: 18, textAlign: 'center', cursor: 'pointer', color: '#9a9aa8', marginBottom: 12 }}>
                🏷️ Upload Logo
                <input type="file" accept="image/*" hidden onChange={e => e.target.files[0] && loadLogo(e.target.files[0])} />
              </label>
              <label style={{ fontSize: '0.78rem', color: '#9a9aa8' }}>Logo Size</label>
              <input type="range" min="10" max="100" value={logoScale * 100} onChange={e => setLogoScale(e.target.value / 100)} style={{ width: '100%', marginBottom: 12 }} />
              <label style={{ fontSize: '0.78rem', color: '#9a9aa8' }}>Name / Text</label>
              <input type="text" value={text} onChange={e => setText(e.target.value)} placeholder="e.g. Dr. Sharma" maxLength={30} style={{ width: '100%', padding: '10px 12px', borderRadius: 8, border: '1px solid #2a2a35', background: '#0f0f12', color: '#f5f5f7', margin: '6px 0' }} />
              <label style={{ fontSize: '0.78rem', color: '#9a9aa8' }}>Text Size</label>
              <input type="range" min="12" max="48" value={textSize} onChange={e => setTextSize(+e.target.value)} style={{ width: '100%' }} />
              <div style={{ marginTop: 8 }}>
                <label style={{ fontSize: '0.78rem', color: '#9a9aa8', marginRight: 8 }}>Colour</label>
                <input type="color" value={textColor} onChange={e => setTextColor(e.target.value)} />
              </div>
              <p style={{ fontSize: '0.78rem', color: '#9a9aa8', marginTop: 10 }}>Drag logo or text on the canvas to place (left chest recommended).</p>
              <div style={{ display: 'flex', gap: 10, marginTop: 16 }}>
                <button onClick={() => setStep(2)} style={{ flex: 1, padding: 12, borderRadius: 10, border: '1px solid #2a2a35', background: 'transparent', color: '#f5f5f7', cursor: 'pointer' }}>← Back</button>
                <button onClick={() => setStep(4)} style={{ flex: 1, padding: 12, borderRadius: 10, border: 'none', background: '#e85d04', color: '#fff', fontWeight: 600, cursor: 'pointer' }}>Finish →</button>
              </div>
            </>
          )}

          {step === 4 && (
            <>
              <h2 style={{ fontSize: '1.05rem', marginBottom: 12 }}>Your Look is Ready</h2>
              <p style={{ fontSize: '0.85rem', color: '#9a9aa8', marginBottom: 16 }}>Download or place order directly.</p>
              <button onClick={download} style={{ width: '100%', padding: 12, borderRadius: 10, border: 'none', background: '#e85d04', color: '#fff', fontWeight: 600, cursor: 'pointer', marginBottom: 10 }}>⬇️ Download Image</button>
              <button onClick={orderWhatsApp} style={{ width: '100%', padding: 12, borderRadius: 10, border: 'none', background: '#25D366', color: '#fff', fontWeight: 600, cursor: 'pointer', marginBottom: 10 }}>💬 Place Order on WhatsApp</button>
              <a href="https://aaomsnepal.com/shop/classic-scrubs" target="_blank" rel="noreferrer" style={{ display: 'block', width: '100%', padding: 12, borderRadius: 10, border: '1px solid #2a2a35', background: 'transparent', color: '#f5f5f7', textAlign: 'center', textDecoration: 'none', marginBottom: 16 }}>View Products on Website</a>
              <div style={{ fontSize: '0.9rem', color: '#9a9aa8', lineHeight: 1.7 }}>
                Style: <strong>{scrubStyle}</strong><br />
                Colour: <strong>{COLORS.find(c => c.id === scrubColor)?.name}</strong><br />
                {height && <>Height: <strong>{height} cm</strong><br /></>}
                {text && <>Name: <strong>{text}</strong><br /></>}
                {logoImg && <>Logo: <strong>Uploaded</strong></>}
              </div>
              <button onClick={() => setStep(3)} style={{ width: '100%', marginTop: 16, padding: 12, borderRadius: 10, border: '1px solid #2a2a35', background: 'transparent', color: '#f5f5f7', cursor: 'pointer' }}>← Edit Again</button>
            </>
          )}
        </div>
      </div>
    </div>
  )
}
