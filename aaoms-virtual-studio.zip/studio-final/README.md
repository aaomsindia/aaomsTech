# aaoms Virtual Dressing Studio

Premium free client-side Virtual Dressing Room for aaomsnepal.com

## Features

- Upload customer photo
- Choose scrub style (V-Neck, Mandarin, Jogger, Stretch)
- 7 colours: Navy, Wine, Maroon, Black, Forest, Heather, Mauve
- Drag + resize scrub on body
- Upload embroidery logo → drag / resize / place
- Type name → change size & colour → drag / place
- Height-based size suggestion
- Download final image
- Place Order via WhatsApp (pre-filled)
- Link to website products
- Fully private (runs in browser)
- Works on HostingRaja Silver plan
- Mobile friendly
- Matches aaoms brand

## Folder Structure

```
studio-final/
├── README.md
├── aaoms-studio.html          ← Standalone version (open in browser to test)
├── components/
│   └── VirtualStudio.jsx      ← React component for Next.js
├── public/
│   ├── garments/              ← Scrub colour overlays + product photos
│   └── models/                ← Transparent full-body models (maroon)
```

## How to Integrate into Next.js (aaomsnepal.com)

### Option A – Quick (Standalone page)

1. Copy `aaoms-studio.html` to your `public/` folder
2. Create a page at `app/studio/page.jsx` (or `pages/studio.js`) that redirects or iframes it
3. Or simply link to `/aaoms-studio.html`

### Option B – Proper React Component (Recommended)

1. Copy `components/VirtualStudio.jsx` into your project
2. Copy the entire `public/garments` and `public/models` folders into your Next.js `public/` folder
3. In `app/studio/page.jsx` (or your existing studio page):

```jsx
import VirtualStudio from '@/components/VirtualStudio'

export default function StudioPage() {
  return <VirtualStudio />
}
```

4. Make sure you have the Inter font or change the font family.

## WhatsApp Number

Currently set to: `9779803840868`

Change it inside the component if needed.

## Notes

- Everything is client-side. No server cost.
- For better realism later you can replace the simple colour shapes with real transparent PNG garment cutouts.
- The maroon full models are included if you want to show “example looks”.

Built for aaoms Nepal — Wear Your Style.
