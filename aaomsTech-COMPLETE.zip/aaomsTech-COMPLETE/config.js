/** aaomsTech COMPLETE — edit only this for API / WhatsApp / flags */
window.AAOMSTECH_CONFIG = {
  apiEndpoint: '/api/aaomstech/request',
  fallback: 'whatsapp',
  whatsappNumber: '9779803840868',
  email: 'aaomsnepal@gmail.com',
  brand: 'aaomsTech',
  // true = built-in quantum canvas; false = use your site hex/3D background
  useParticles: true,
  useHexField: true,
  idleRevealSeconds: 12,
  minExchangesBeforeServices: 1,
  services: [
    { id: 'software-dev', icon: '⟨/⟩', name: 'Software Development', desc: 'Code built for Nepal, scaled for the world.', tag: '// core · nepal' },
    { id: 'web-app-design', icon: '◈', name: 'Website & App Design', desc: 'Interfaces for the next generation of Nepali businesses.', tag: '// visual · future' },
    { id: 'data-analytics', icon: '≋', name: 'Data Analytics', desc: 'Turn Nepal data into clear decisions.', tag: '// signal · insight' },
    { id: 'cloud-infra', icon: '☁', name: 'Cloud Infrastructure', desc: 'Systems that stay online under load.', tag: '// lattice · cloud' },
    { id: 'ecommerce', icon: '⬡', name: 'E-commerce Platforms', desc: 'Commerce ready for Nepal and beyond.', tag: '// commerce · grow' },
    { id: 'ai-automation', icon: '◎', name: 'AI & Automation', desc: 'Practical AI workflows and automation for real teams.', tag: '// neural · ops' }
  ]
};
