# aaomsTech COMPLETE — Quantum World Package

## Feel
Real quantum section: particle lattice, moving hex field, neon circuits, pulsing orb, holographic terminal.

## Intelligence
- Quick techy replies across software / web / data / cloud / ecom / security / DevOps / Nepal stack
- Large expansion pack (100s of keyword paths → large answer surface; keep adding to knowledge-expand.js)
- EN · नेपाली · हिन्दी detection
- Memory of chat style + language
- Never silent ambient typing
- Services unlock when customer STOPS asking (compulsory idle reveal)

## Files
config.js · knowledge-expand.js · knowledge.js · i18n.js · memory.js · script.js · style.css · index.html · assets/

## Claude integrate
Embed section or host as /aaomstech. Load scripts in HTML order.
Set useParticles/useHexField false if site already has full quantum BG.

WhatsApp: 9779803840868
