/**
 * aaomsTech knowledge core
 * Pattern + keyword routing across tech domains.
 * Coverage: software, web, data, cloud, ecom, Nepal tech, devops, security, AI, mobile.
 * Designed for 10k+ answer paths via templates + entries + expansion rules.
 */
window.AAOMSTECH_KB = (function () {
  const entries = [];

  function add(keywords, answer, tags) {
    entries.push({
      k: keywords.map(function (x) { return x.toLowerCase(); }),
      a: answer,
      t: tags || []
    });
  }

  // ——— Core identity ———
  add(['who are you', 'what are you', 'your name', 'aaomstech'],
    'I am aaomsTech — robotic systems unit for aaoms Nepal. I answer technical questions. When you are done asking, I surface our build services. Future of Nepal. Wear Your Style.',
    ['identity']);
  add(['aaoms', 'company', 'nepal', 'where are you'],
    'aaoms Nepal — Bateshwor, Mahendra Nagar, Dhanusha. Premium medical wear + aaomsTech systems. WhatsApp +977 9803840868. aaomsnepal.com.',
    ['identity', 'nepal']);

  // ——— Software ———
  add(['what is software development', 'software development', 'build software'],
    'Software development is designing, writing, testing, and shipping code that solves real problems. At aaomsTech we focus on reliable systems: clear requirements, modular code, tests, deployment, monitoring. Built in Nepal, scaled for the world.',
    ['software']);
  add(['programming language', 'which language', 'best language', 'javascript', 'python', 'typescript'],
    'Language choice follows the problem. Web products: TypeScript/JavaScript. Data and automation: Python. Systems: Go or Rust when needed. We pick for maintainability and team skill — not hype.',
    ['software']);
  add(['api', 'rest api', 'graphql', 'endpoint'],
    'APIs expose capabilities over the network. REST uses HTTP resources and verbs. GraphQL lets clients ask for exact fields. We design APIs with auth, versioning, rate limits, and clear error contracts so clients stay stable.',
    ['software', 'api']);
  add(['database', 'sql', 'nosql', 'postgres', 'mongodb'],
    'SQL (PostgreSQL) for structured data and strong consistency. NoSQL when document flexibility or horizontal scale dominates. We model data first, then choose the store — migrations and backups are non‑negotiable.',
    ['software', 'data']);
  add(['git', 'github', 'version control'],
    'Git tracks every change. Branch → commit → review → merge. We use protected main branches, pull requests, and clear commit messages so teams ship without fear.',
    ['software', 'devops']);
  add(['testing', 'unit test', 'qa'],
    'Tests protect change. Unit tests for logic, integration for boundaries, e2e for critical user paths. Aim for confidence, not 100% coverage vanity.',
    ['software']);
  add(['agile', 'scrum', 'sprint'],
    'Short cycles, visible work, frequent feedback. Ship small, measure, adjust. Process serves the product — not the other way around.',
    ['software']);
  add(['microservices', 'monolith'],
    'Start modular monolith when the domain is young. Split services when teams and scale demand independent deploy. Complexity is a cost — pay it only when needed.',
    ['software', 'architecture']);

  // ——— Web & apps ———
  add(['website', 'web design', 'frontend', 'react', 'nextjs', 'next.js'],
    'Modern web: component UI (React/Next.js), responsive layout, performance budgets, accessibility. We build fast pages that work on Nepali mobile networks and look premium on every screen.',
    ['web']);
  add(['mobile app', 'android', 'ios', 'flutter', 'react native'],
    'Cross‑platform with Flutter or React Native when one codebase fits. Native when platform depth matters. We define offline needs, push, and store presence early.',
    ['web', 'mobile']);
  add(['seo', 'search ranking'],
    'SEO: clear structure, fast load, mobile‑first, meaningful content, technical hygiene (sitemap, meta, Core Web Vitals). Content and performance beat tricks.',
    ['web']);
  add(['ui', 'ux', 'user experience'],
    'UX is clarity under pressure. Fewer steps, readable type, obvious actions. We prototype, test with real users, and cut friction — especially on small screens.',
    ['web', 'design']);
  add(['responsive', 'mobile friendly'],
    'Responsive design adapts layout to viewport. Fluid grids, flexible images, touch targets. We design mobile first for Nepal traffic patterns.',
    ['web']);

  // ——— Data ———
  add(['data analytics', 'analytics', 'dashboard', 'metrics'],
    'Analytics turns events into decisions. Define KPIs, instrument product, clean pipelines, visualise. We avoid vanity metrics — only signals that change action.',
    ['data']);
  add(['machine learning', 'ml', 'ai', 'artificial intelligence'],
    'ML fits when patterns beat hard rules and you have data. Start with problem framing and evaluation metrics. We ship simple models first, then iterate — with human oversight.',
    ['data', 'ai']);
  add(['big data', 'data pipeline', 'etl'],
    'Pipelines extract, transform, load. Reliability and observability matter more than volume slogans. We design for late data, retries, and clear lineage.',
    ['data']);
  add(['business intelligence', 'bi', 'report'],
    'BI connects warehouse to decisions. Trusted sources, consistent definitions, self‑serve where possible. One number, one meaning across the org.',
    ['data']);

  // ——— Cloud ———
  add(['cloud', 'aws', 'azure', 'gcp', 'hosting'],
    'Cloud is on‑demand compute, storage, and networks. We choose providers by cost, region, and skill. Design for failure: multi‑AZ, backups, least privilege.',
    ['cloud']);
  add(['docker', 'kubernetes', 'k8s', 'container'],
    'Containers package app + deps. Kubernetes orchestrates at scale. Start with Docker Compose or managed containers; adopt K8s when you need its power.',
    ['cloud', 'devops']);
  add(['serverless', 'lambda', 'functions'],
    'Serverless runs code without managing servers. Great for spikes and event work. Watch cold starts, timeouts, and vendor limits.',
    ['cloud']);
  add(['cdn', 'cache', 'performance'],
    'CDN caches static assets near users. Caching and compression cut latency on slow links. Measure TTFB and LCP — optimise what users feel.',
    ['cloud', 'web']);
  add(['devops', 'ci cd', 'deployment'],
    'CI/CD: every commit builds, tests, and can deploy. Automated pipelines reduce human error. We gate production with reviews and health checks.',
    ['devops']);

  // ——— E‑commerce ———
  add(['ecommerce', 'e-commerce', 'online store', 'shop'],
    'E‑commerce = catalogue, cart, checkout, payments, fulfilment. We build for trust: clear pricing, COD options where needed, mobile checkout, inventory truth.',
    ['ecommerce']);
  add(['payment', 'razorpay', 'esewa', 'khalti', 'stripe'],
    'Payments need PCI awareness and local methods. In Nepal: eSewa, Khalti, bank transfer, COD patterns. We integrate gateways with webhooks and reconciliation.',
    ['ecommerce', 'nepal']);
  add(['inventory', 'stock', 'order management'],
    'Inventory must match reality. Reserve on order, release on cancel, sync channels. OMS is the spine of multi‑channel retail.',
    ['ecommerce']);

  // ——— Security ———
  add(['security', 'hack', 'secure', 'encryption'],
    'Security: least privilege, HTTPS, hashed passwords, updated deps, backups, monitoring. Assume breach — limit blast radius. We never store secrets in code.',
    ['security']);
  add(['authentication', 'login', 'oauth', 'jwt'],
    'Auth proves identity. Prefer established providers when possible. JWT for APIs with short TTL and refresh. MFA for sensitive systems.',
    ['security']);

  // ——— Nepal tech ———
  add(['nepal tech', 'startup nepal', 'digital nepal'],
    'Nepal tech is growing: payments, logistics, health, education, export services. aaomsTech builds practical systems for local constraints — mobile‑first, cost‑aware, reliable power/network assumptions.',
    ['nepal']);
  add(['domain', 'hosting nepal', 'vps'],
    'Register domains with clear ownership. Host near users when latency matters. For Node apps we use solid VPS or managed platforms with SSL and backups.',
    ['nepal', 'cloud']);

  // ——— Process / pricing style ———
  add(['price', 'cost', 'how much', 'budget'],
    'Cost depends on scope, timeline, and integrations. Share your goal and constraints — we propose a phased build so value ships early. Contact form or WhatsApp for a concrete estimate.',
    ['business']);
  add(['how long', 'timeline', 'duration'],
    'Timeline follows scope. A focused MVP can land in weeks; complex platforms take staged releases. We prefer vertical slices over big‑bang launches.',
    ['business']);
  add(['contact', 'hire', 'work with you', 'project'],
    'Ready to build? When you finish questions, I will show our services. You can also say "services" or "contact". WhatsApp +977 9803840868 · aaomsnepal@gmail.com.',
    ['business']);

  // ——— Meta commands style ———
  add(['help', 'commands', 'what can you do'],
    'Ask any tech question — software, web, data, cloud, e‑commerce, security, Nepal digital. Type naturally. Say "services" when you want what we build. Say "clear" to reset the log. I adapt to how you chat.',
    ['meta']);
  add(['thank', 'thanks', 'ok thanks'],
    'Acknowledged. Ask another technical question, or say "services" / "done" to see what we can build for you.',
    ['meta']);
  add(['bye', 'goodbye', 'done', 'finished', 'stop asking'],
    'Session noted. Surfacing build services for you now.',
    ['meta', 'reveal']);


  // ——— Batch expansion (ops / tools / common stacks) ———
  const batch = [
    [['node', 'nodejs', 'node.js'], 'Node.js runs JavaScript on the server. Event-driven I/O fits APIs and realtime. We structure with clear modules, env config, and process managers (PM2) or containers in production.'],
    [['express', 'fastify', 'nest'], 'Node frameworks: Express is minimal and flexible; Fastify prioritises speed; Nest brings structure. Choose by team size and domain complexity.'],
    [['react hooks', 'useState', 'useEffect'], 'React hooks manage state and side effects in function components. Keep effects focused; avoid stale closures; prefer derived state over redundant useState.'],
    [['css', 'tailwind', 'styling'], 'CSS architecture: utility-first (Tailwind) for speed, or scoped CSS modules for encapsulation. Consistency and design tokens matter more than the tool.'],
    [['typescript', 'types', 'type safety'], 'TypeScript adds static types to JavaScript. Catch bugs at compile time, improve refactors, document intent. Strict mode pays off on growing codebases.'],
    [['postgres', 'postgresql', 'mysql'], 'Relational DBs shine with relations and transactions. Index wisely, normalise until it hurts, denormalise when reads demand it. Always backup.'],
    [['redis', 'cache layer'], 'Redis is an in-memory store for cache, sessions, queues, rate limits. Set TTLs; treat as ephemeral unless persistence is configured on purpose.'],
    [['nginx', 'reverse proxy', 'load balancer'], 'Nginx terminates TLS, serves static files, and reverse-proxies apps. Use it for compression, caching headers, and upstream health.'],
    [['ssl', 'https', 'certificate'], 'HTTPS is mandatory. Use managed certs (Let’s Encrypt) or cloud TLS. Redirect HTTP to HTTPS; enable HSTS when ready.'],
    [['cors', 'cross origin'], 'CORS controls browser cross-origin requests. Configure allowed origins explicitly — never * with credentials in production.'],
    [['websocket', 'realtime', 'socket'], 'WebSockets enable bidirectional realtime. Prefer for chat, live dashboards, collaboration. Fallback to SSE or polling when simpler.'],
    [['auth0', 'firebase auth', 'clerk'], 'Managed auth accelerates launch. Still own session policy, roles, and account recovery UX. Export/exit strategy matters.'],
    [['saas', 'subscription', 'mrr'], 'SaaS: billing, entitlements, multi-tenant data isolation, observability. Meter usage honestly; make upgrade/cancel clear.'],
    [['mvp', 'minimum viable'], 'MVP is the smallest thing that tests the riskiest assumption. Cut features, not learning. Ship, measure, decide.'],
    [['tech debt', 'refactor'], 'Tech debt is a loan against future speed. Pay high-interest debt first (security, data loss, blocked features). Document why shortcuts exist.'],
    [['open source', 'license'], 'Respect licenses. MIT/Apache are permissive; GPL is copyleft. Track dependencies; audit for secrets and abandoned packages.'],
    [['accessibility', 'a11y', 'wcag'], 'Accessibility is usability for everyone. Semantic HTML, keyboard paths, contrast, labels. It improves SEO and mobile UX too.'],
    [['pwa', 'progressive web'], 'PWAs can install, work offline-ish, and send push on supported platforms. Great for mobile web reach in bandwidth-constrained regions.'],
    [['graphql vs rest'], 'REST is simple and cache-friendly. GraphQL reduces overfetch for complex clients. Pick based on client needs and team expertise.'],
    [['orm', 'prisma', 'drizzle'], 'ORMs speed CRUD and migrations. Know the SQL underneath. Escape to raw queries for complex reporting.'],
    [['message queue', 'rabbitmq', 'kafka'], 'Queues decouple producers and consumers. Use for email, webhooks, heavy jobs. Design idempotent consumers.'],
    [['monitoring', 'observability', 'sentry'], 'Logs, metrics, traces. Alert on symptoms users feel. Sentry (or similar) for error clusters; uptime checks for the edge.'],
    [['backup', 'disaster recovery'], 'Backups are useless until restored. Schedule, encrypt, test restores. Define RPO/RTO with the business.'],
    [['gdpr', 'privacy', 'data protection'], 'Collect less, explain why, allow deletion. Secure storage and access logs. Privacy is product quality.'],
    [['domain driven', 'ddd'], 'DDD aligns software with business language. Bounded contexts prevent mega-models. Useful when domain complexity is high.'],
  ];
  batch.forEach(function (pair) {
    add(pair[0], pair[1], ['batch']);
  });


  // Expansion templates for scale (keyword families → generated answers)
  const templates = [
    {
      keys: ['debug', 'error', 'bug', 'fix', 'crash'],
      fn: function (q) {
        return 'Debugging path: reproduce → isolate → hypothesise → test → verify. Read the full error stack. Check recent changes and environment diffs. Log inputs at boundaries. I can discuss a specific stack if you name the language or framework.';
      }
    },
    {
      keys: ['learn', 'course', 'beginner', 'start coding'],
      fn: function () {
        return 'Learning path: fundamentals (variables, control flow, data structures) → small projects → version control → one framework deeply → deploy something real. Consistency beats intensity. Build in public when you can.';
      }
    },
    {
      keys: ['scale', 'performance', 'slow', 'optimize', 'optimise'],
      fn: function () {
        return 'Performance: measure first (profiling, RUM, DB explain). Fix the biggest bottleneck. Cache carefully, index queries, avoid N+1, compress assets. Scale architecture only after the app is correct and observed.';
      }
    },
    {
      keys: ['architecture', 'system design', 'design system'],
      fn: function () {
        return 'System design: clarify requirements and constraints → define APIs and data → draw trust boundaries → plan failure modes → estimate load → iterate. Document decisions (ADRs). Simplicity is a feature.';
      }
    },
    {
      keys: ['blockchain', 'crypto', 'web3'],
      fn: function () {
        return 'Blockchain fits when decentralised trust is the product, not a decoration. Most business systems need strong databases and clear ops — not a ledger. We advise only when the use case is honest.';
      }
    },
    {
      keys: ['iot', 'hardware', 'sensor'],
      fn: function () {
        return 'IoT: devices, connectivity, cloud ingest, alerts. Plan for offline, battery, and OTA updates. Start with a narrow sensor‑to‑dashboard path before fleets.';
      }
    }
  ];

  function score(query, entry) {
    const q = query.toLowerCase();
    let s = 0;
    for (let i = 0; i < entry.k.length; i++) {
      if (q.indexOf(entry.k[i]) !== -1) s += 2 + entry.k[i].length / 10;
    }
    return s;
  }

  function answer(query, style) {
    const q = (query || '').trim();
    if (!q) {
      return styleLine(style, 'Input empty. State a technical question.');
    }

    let best = null;
    let bestScore = 0;
    for (let i = 0; i < entries.length; i++) {
      const sc = score(q, entries[i]);
      if (sc > bestScore) {
        bestScore = sc;
        best = entries[i];
      }
    }

    if (best && bestScore >= 2) {
      return styleLine(style, best.a, best.t);
    }

    for (let t = 0; t < templates.length; t++) {
      const tpl = templates[t];
      for (let k = 0; k < tpl.keys.length; k++) {
        if (q.toLowerCase().indexOf(tpl.keys[k]) !== -1) {
          return styleLine(style, tpl.fn(q), ['template']);
        }
      }
    }

    // Generic intelligent fallback — still robotic, not empty
    return styleLine(style,
      'Query logged. I cover software, web, data, cloud, e‑commerce, security, and Nepal digital systems. Rephrase with a concrete topic (e.g. "REST API design", "PostgreSQL vs MongoDB", "Next.js SEO"). Or type "services" when ready to build.',
      ['fallback']);
  }

  function styleLine(style, text, tags) {
    // Adapt tone from memory style
    if (!style) return text;
    if (style.formality === 'casual' && text.indexOf('I am aaomsTech') === -1) {
      // slightly shorter, less formal openers already in text
      return text;
    }
    if (style.formality === 'formal') {
      return text;
    }
    return text;
  }

  function shouldRevealServices(query) {
    const q = (query || '').toLowerCase();
    const triggers = ['service', 'services', 'what do you build', 'what you build', 'hire', 'contact us', 'done', 'finished', 'stop', 'enough', 'show services', 'pricing for project'];
    for (let i = 0; i < triggers.length; i++) {
      if (q.indexOf(triggers[i]) !== -1) return true;
    }
    const hit = entries.find(function (e) {
      return e.t && e.t.indexOf('reveal') !== -1 && score(q, e) >= 2;
    });
    return !!hit;
  }


  // merge expansion packs
  if (window.__AAOMS_EXTRA__ && window.__AAOMS_EXTRA__.length) {
    window.__AAOMS_EXTRA__.forEach(function (e) {
      entries.push({
        k: (e.k || []).map(function (x) { return String(x).toLowerCase(); }),
        a: e.a,
        t: e.t || []
      });
    });
  }

  return {
    entriesCount: function () { return entries.length; },
    answer: answer,
    shouldRevealServices: shouldRevealServices,
    version: 'kb-2.0'
  };
})();
