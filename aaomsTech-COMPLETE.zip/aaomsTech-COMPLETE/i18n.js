/**
 * aaomsTech — EN / NE / HI language detect + replies
 */
window.AAOMSTECH_I18N = (function () {
  // Devanagari range used by Nepali & Hindi
  const deva = /[\u0900-\u097F]/;

  // Nepali-leaning markers
  const neMarks = /छ|हो|के|गर्न|छन्|हामी|तपाईं|नमस्ते|धन्यवाद|कस्तो|छौ|हुन्छ|नेपाल|के हो|बनाउ|सेवा/;
  // Hindi-leaning markers  
  const hiMarks = /है|हैं|क्या|कृपया|आप|धन्यवाद|नमस्ते|कैसे|बनाएं|सेवा|करें|मुझे|चाहिए/;

  function detect(text) {
    const t = (text || '').trim();
    if (!t) return 'en';
    if (!deva.test(t)) return 'en';
    const ne = (t.match(neMarks) || []).length;
    const hi = (t.match(hiMarks) || []).length;
    // Shared words (नमस्ते, धन्यवाद) — prefer more specific hits
    if (ne > hi) return 'ne';
    if (hi > ne) return 'hi';
    // Default Devanagari → try both; prefer ne for aaoms Nepal context if tied
    if (/\b(hai|kya|kaise|chahiye)\b/i.test(t)) return 'hi';
    return 'ne';
  }

  const phrases = {
    en: {
      boot1: '[SYS] aaomsTech robotic shell · boot sequence',
      boot2: '[OK]  knowledge lattice online · EN · नेपाली · हिन्दी',
      boot3: '[OK]  interaction memory ready',
      ask: 'Ask in English, नेपाली, or हिन्दी. Services unlock when you stop asking.',
      cleared: '[OK] log cleared · memory retained',
      surfacing: '[SYS] Surfacing build modules…',
      empty: 'Input empty. State a technical question.',
      fallback: 'I cover software, web, data, cloud, e-commerce, security. Ask a concrete topic — or type services when ready.',
      servicesHint: 'Type "services" / "सेवा" / "सेवाएँ" when done asking.'
    },
    ne: {
      boot1: '[SYS] aaomsTech रोबोटिक शेल · बुट',
      boot2: '[OK]  ज्ञान प्रणाली अनलाइन · अंग्रेजी · नेपाली · हिन्दी',
      boot3: '[OK]  कुराकानी मेमोरी तयार',
      ask: 'अंग्रेजी, नेपाली वा हिन्दीमा सोध्नुहोस्। प्रश्न रोकिएपछि सेवा देखिन्छ।',
      cleared: '[OK] लग खाली · मेमोरी सुरक्षित',
      surfacing: '[SYS] निर्माण सेवा देखाउँदै…',
      empty: 'खाली इनपुट। प्राविधिक प्रश्न लेख्नुहोस्।',
      fallback: 'सफ्टवेयर, वेब, डाटा, क्लाउड, ई-कमर्स समेट्छु। स्पष्ट विषय सोध्नुहोस् — वा "सेवा" लेख्नुहोस्।',
      servicesHint: 'प्रश्न सकिएपछि "सेवा" वा "services" लेख्नुहोस्।'
    },
    hi: {
      boot1: '[SYS] aaomsTech रोबोटिक शेल · बूट',
      boot2: '[OK]  ज्ञान प्रणाली ऑनलाइन · अंग्रेज़ी · नेपाली · हिन्दी',
      boot3: '[OK]  बातचीत मेमोरी तैयार',
      ask: 'अंग्रेज़ी, नेपाली या हिन्दी में पूछें। सवाल बंद होने पर सेवाएँ दिखेंगी।',
      cleared: '[OK] लॉग साफ़ · मेमोरी सुरक्षित',
      surfacing: '[SYS] बिल्ड सेवाएँ दिखा रहे हैं…',
      empty: 'खाली इनपुट। तकनीकी सवाल लिखें।',
      fallback: 'सॉफ़्टवेयर, वेब, डेटा, क्लाउड, ई-कॉमर्स। स्पष्ट विषय पूछें — या "सेवाएँ" लिखें।',
      servicesHint: 'सवाल खत्म हों तो "सेवाएँ" या "services" लिखें।'
    }
  };

  // Multilingual core answers (key topic → 3 langs)
  const topics = {
    identity: {
      en: 'I am aaomsTech — robotic unit for aaoms Nepal. I answer tech questions in English, नेपाली, हिन्दी. When you stop asking, services appear. Future of Nepal.',
      ne: 'म aaomsTech हुँ — aaoms Nepal को रोबोटिक प्रणाली। अंग्रेजी, नेपाली, हिन्दीमा प्राविधिक प्रश्नको जवाफ दिन्छु। प्रश्न रोकिएपछि सेवा देखिन्छ। नेपालको भविष्य।',
      hi: 'मैं aaomsTech हूँ — aaoms Nepal की रोबोटिक प्रणाली। अंग्रेज़ी, नेपाली, हिन्दी में तकनीकी जवाब देता हूँ। सवाल बंद होने पर सेवाएँ दिखती हैं। नेपाल का भविष्य।'
    },
    software: {
      en: 'Software development: design, code, test, ship, monitor. We build reliable systems in Nepal for the world — modular code, tests, clear deploy.',
      ne: 'सफ्टवेयर विकास: डिजाइन, कोड, परीक्षण, डेलिभरी, निगरानी। हामी नेपालबाट विश्वका लागि भरपर्दो प्रणाली बनाउँछौं।',
      hi: 'सॉफ़्टवेयर विकास: डिज़ाइन, कोड, टेस्ट, शिप, मॉनिटर। हम नेपाल से दुनिया के लिए विश्वसनीय सिस्टम बनाते हैं।'
    },
    web: {
      en: 'Web: fast, mobile-first, accessible. React/Next when needed. Built for real Nepal network conditions.',
      ne: 'वेब: छिटो, मोबाइल-पहिलो, पहुँचयोग्य। आवश्यकताअनुसार React/Next। नेपालको नेटवर्क अवस्थाका लागि।',
      hi: 'वेब: तेज़, मोबाइल-फर्स्ट, सुलभ। ज़रूरत पर React/Next। नेपाल की नेटवर्क स्थिति के अनुकूल।'
    },
    data: {
      en: 'Data analytics turns events into decisions. Define KPIs, clean pipelines, honest dashboards — no vanity metrics.',
      ne: 'डाटा एनालिटिक्सले घटनालाई निर्णयमा बदल्छ। KPI, सफा पाइपलाइन, इमानदार ड्यासबोर्ड।',
      hi: 'डेटा एनालिटिक्स घटनाओं को निर्णयों में बदलता है। KPI, साफ़ पाइपलाइन, ईमानदार डैशबोर्ड।'
    },
    cloud: {
      en: 'Cloud: on-demand compute and storage. Design for failure — backups, least privilege, monitor what users feel.',
      ne: 'क्लाउड: मागअनुसार कम्प्युट र स्टोरेज। असफलताको लागि डिजाइन — ब्याकअप, न्यूनतम अनुमति, निगरानी।',
      hi: 'क्लाउड: मांग पर कंप्यूट और स्टोरेज। विफलता के लिए डिज़ाइन — बैकअप, न्यूनतम अधिकार, निगरानी।'
    },
    ecommerce: {
      en: 'E-commerce: catalogue, cart, checkout, local payments, inventory truth. Mobile checkout matters in Nepal.',
      ne: 'ई-कमर्स: क्याटलग, कार्ट, चेकआउट, स्थानीय भुक्तानी, स्टक सत्यता। नेपालमा मोबाइल चेकआउट महत्त्वपूर्ण।',
      hi: 'ई-कॉमर्स: कैटलॉग, कार्ट, चेकआउट, स्थानीय भुगतान, इन्वेंटरी। नेपाल में मोबाइल चेकआउट ज़रूरी।'
    },
    contact: {
      en: 'Ready to build? When you finish questions, services appear. WhatsApp +977 9803840868 · aaomsnepal@gmail.com',
      ne: 'बनाउन तयार? प्रश्न सकिएपछि सेवा देखिन्छ। WhatsApp +977 9803840868 · aaomsnepal@gmail.com',
      hi: 'बनाने को तैयार? सवाल खत्म हों तो सेवाएँ दिखेंगी। WhatsApp +977 9803840868 · aaomsnepal@gmail.com'
    },
    services: {
      en: 'Surfacing what we build: Software, Web & App Design, Data Analytics, Cloud, E-commerce.',
      ne: 'हामीले बनाउने सेवा: सफ्टवेयर, वेब र एप डिजाइन, डाटा एनालिटिक्स, क्लाउड, ई-कमर्स।',
      hi: 'हमारी सेवाएँ: सॉफ़्टवेयर, वेब और ऐप डिज़ाइन, डेटा एनालिटिक्स, क्लाउड, ई-कॉमर्स।'
    }
  };

  const topicKeys = {
    identity: ['who are you', 'what are you', 'aaomstech', 'तपाईं को हो', 'के हो', 'तुम कौन', 'कौन हो'],
    software: ['software', 'सफ्टवेयर', 'सॉफ्टवेयर', 'programming', 'कोड', 'code'],
    web: ['website', 'web', 'वेब', 'वेबसाइट', 'frontend', 'react'],
    data: ['data', 'analytics', 'डाटा', 'डेटा', 'एनालिटिक्स'],
    cloud: ['cloud', 'क्लाउड', 'aws', 'server', 'सर्भर'],
    ecommerce: ['ecommerce', 'e-commerce', 'shop', 'ई-कमर्स', 'ईकॉमर्स', 'store'],
    contact: ['contact', 'hire', 'सम्पर्क', 'संपर्क', 'काम', 'project'],
    services: ['service', 'services', 'सेवा', 'सेवाएँ', 'सेवाहरु', 'done', 'finished', 'सकियो', 'बस']
  };

  function matchTopic(q) {
    const lower = q.toLowerCase();
    for (const topic of Object.keys(topicKeys)) {
      for (const k of topicKeys[topic]) {
        if (lower.indexOf(k.toLowerCase()) !== -1 || q.indexOf(k) !== -1) return topic;
      }
    }
    return null;
  }

  function t(lang, key) {
    return (phrases[lang] && phrases[lang][key]) || phrases.en[key] || key;
  }

  function answerTopic(topic, lang) {
    const block = topics[topic];
    if (!block) return null;
    return block[lang] || block.en;
  }

  // Ambient interesting lines (never stop while on page)
  const ambient = {
    en: [
      '[···] Lattice coherence nominal · Nepal node online',
      '[···] Tip: measure before optimising — profile, then fix',
      '[···] Mobile-first still wins on South Asian networks',
      '[···] Backups only count if you have restored once',
      '[···] Future of Nepal · systems that stay online',
      '[···] Ask freely · services unlock when you pause',
      '[···] HTTPS, least privilege, monitor what users feel',
      '[···] Ship small · learn fast · iterate'
    ],
    ne: [
      '[···] नेपाल नोड अनलाइन · प्रणाली स्थिर',
      '[···] सुझाव: मापन गर्नुहोस् — अनि मात्र अनुकूलन',
      '[···] मोबाइल-पहिलो डिजाइन अझै महत्त्वपूर्ण',
      '[···] ब्याकअप तब मात्र काम लाग्छ जब रिकभरी परीक्षण हुन्छ',
      '[···] नेपालको भविष्य · अनलाइन रहने प्रणाली',
      '[···] स्वतन्त्र सोध्नुहोस् · रोकिएपछि सेवा',
      '[···] सानो शिप · छिटो सिक्नु · दोहोर्याउनु'
    ],
    hi: [
      '[···] नेपाल नोड ऑनलाइन · सिस्टम स्थिर',
      '[···] टिप: पहले मापें — फिर ऑप्टिमाइज़ करें',
      '[···] मोबाइल-फर्स्ट डिज़ाइन अभी भी ज़रूरी',
      '[···] बैकअप तभी काम का जब रिकवरी टेस्ट हो',
      '[···] नेपाल का भविष्य · ऑनलाइन रहने वाले सिस्टम',
      '[···]자유롭게 पूछें · रुकने पर सेवाएँ',
      '[···] छोटा शिप · तेज़ सीख · दोहराएँ'
    ]
  };

  function ambientLine(lang) {
    const list = ambient[lang] || ambient.en;
    return list[Math.floor(Math.random() * list.length)];
  }

  function shouldReveal(q) {
    const topic = matchTopic(q);
    if (topic === 'services' || topic === 'contact') return true;
    const lower = (q || '').toLowerCase();
    return /^(done|stop|enough|finished|thank|thanks|सेवा|सकियो|बस|हो गया|धन्यवाद)/i.test(lower.trim());
  }

  return {
    detect: detect,
    t: t,
    matchTopic: matchTopic,
    answerTopic: answerTopic,
    ambientLine: ambientLine,
    shouldReveal: shouldReveal
  };
})();
