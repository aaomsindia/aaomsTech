/**
 * Customer interaction memory (localStorage)
 * Remembers formality, topics, message length style, visit count
 */
window.AAOMSTECH_MEMORY = (function () {
  const KEY = 'aaomstech_memory_v1';

  function load() {
    try {
      const raw = localStorage.getItem(KEY);
      if (!raw) return defaultMem();
      return Object.assign(defaultMem(), JSON.parse(raw));
    } catch (e) {
      return defaultMem();
    }
  }

  function defaultMem() {
    return {
      visits: 0,
      exchanges: 0,
      formality: 'neutral',
      lang: 'en', // en | ne | hi
      avgLen: 40,
      topics: {},
      lastSeen: null,
      nameHint: null
    };
  }

  function save(mem) {
    try {
      localStorage.setItem(KEY, JSON.stringify(mem));
    } catch (e) { /* ignore */ }
  }

  function observe(userText, lang) {
    const mem = load();
    mem.exchanges += 1;
    mem.lastSeen = new Date().toISOString();
    if (lang) mem.lang = lang;

    const t = (userText || '').trim();
    const len = t.length;
    mem.avgLen = Math.round((mem.avgLen * 0.7) + (len * 0.3));

    // Formality heuristics
    const lower = t.toLowerCase();
    const formalMarks = (lower.match(/\b(please|kindly|would you|could you|sir|madam|regarding)\b/g) || []).length;
    const casualMarks = (lower.match(/\b(hey|hi|yo|lol|cool|yeah|nah|thx|thanks!)\b/g) || []).length;
    const hasEmoji = /[\u{1F300}-\u{1F9FF}]/u.test(t);
    if (formalMarks > casualMarks) mem.formality = 'formal';
    else if (casualMarks > 0 || hasEmoji || len < 25) mem.formality = 'casual';
    else if (len > 120) mem.formality = 'formal';
    else mem.formality = 'neutral';

    // Topic tags
    const topicMap = {
      software: ['code', 'program', 'software', 'api', 'git'],
      web: ['website', 'web', 'react', 'frontend', 'seo'],
      data: ['data', 'analytics', 'sql', 'ml', 'ai'],
      cloud: ['cloud', 'aws', 'docker', 'deploy', 'server'],
      ecommerce: ['shop', 'store', 'payment', 'ecommerce', 'order'],
      nepal: ['nepal', 'kathmandu', 'esewa', 'khalti']
    };
    Object.keys(topicMap).forEach(function (topic) {
      topicMap[topic].forEach(function (kw) {
        if (lower.indexOf(kw) !== -1) {
          mem.topics[topic] = (mem.topics[topic] || 0) + 1;
        }
      });
    });

    // Name capture "I am X" / "my name is X"
    const nameMatch = t.match(/(?:i am|i'm|my name is|this is)\s+([A-Za-z]{2,30})/i);
    if (nameMatch) mem.nameHint = nameMatch[1];

    save(mem);
    return mem;
  }

  function touchVisit() {
    const mem = load();
    mem.visits = (mem.visits || 0) + 1;
    mem.lastSeen = new Date().toISOString();
    save(mem);
    return mem;
  }

  function greeting(mem) {
    const name = mem.nameHint ? ', ' + mem.nameHint : '';
    if (mem.visits > 1 && mem.exchanges > 2) {
      if (mem.formality === 'casual') {
        return 'Session resumed' + name + '. I still have your prior context. Ask anything technical — or say services when ready.';
      }
      return 'Welcome back' + name + '. Interaction profile loaded. State your technical query, or request services.';
    }
    return 'aaomsTech online' + name + '. Ask technical questions freely. Services appear after you finish asking — or type services.';
  }

  function adaptPrefix(mem) {
    if (mem.formality === 'casual') return '';
    if (mem.formality === 'formal') return '';
    return '';
  }

  return {
    load: load,
    observe: observe,
    touchVisit: touchVisit,
    greeting: greeting,
    adaptPrefix: adaptPrefix
  };
})();
