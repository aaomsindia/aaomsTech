/**
 * aaomsTech COMPLETE — quantum world + hex field + robot Q&A (EN/NE/HI)
 */
(function () {
  const CFG = window.AAOMSTECH_CONFIG || {};
  const KB = window.AAOMSTECH_KB;
  const MEM = window.AAOMSTECH_MEMORY;
  const I18N = window.AAOMSTECH_I18N;
  const services = CFG.services || [];

  const termBody = document.getElementById('termBody');
  const termInput = document.getElementById('termInput');
  const sendBtn = document.getElementById('sendBtn');
  const servicesSection = document.getElementById('servicesSection');
  const cardsEl = document.getElementById('cards');
  const memBadge = document.getElementById('memBadge');
  const kbStat = document.getElementById('kbStat');
  const coherenceEl = document.getElementById('coherenceVal');

  let typing = false;
  let exchangeCount = 0;
  let servicesRevealed = false;
  let idleTimer = null;
  let ambientTimer = null;
  let selectedService = null;
  let sessionLang = 'en';
  let pageVisible = true;

  function tickClock() {
    const el = document.getElementById('liveClock');
    if (!el) return;
    try {
      el.textContent = new Intl.DateTimeFormat('en-GB', {
        timeZone: 'Asia/Kathmandu', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false
      }).format(new Date()) + ' NPT';
    } catch (e) {
      el.textContent = new Date().toTimeString().slice(0, 8) + ' NPT';
    }
  }
  setInterval(tickClock, 1000);
  tickClock();
  setInterval(function () {
    if (coherenceEl) coherenceEl.textContent = (99.90 + Math.random() * 0.09).toFixed(2) + '%';
  }, 2400);

  if (kbStat && KB) {
    const n = typeof KB.entriesCount === 'function' ? KB.entriesCount() : 0;
    kbStat.textContent = 'KB · ' + n + '+ PATHS';
  }

  /* ——— Quantum particles ——— */
  const qCanvas = document.getElementById('quantumCanvas');
  if (CFG.useParticles !== false && qCanvas) {
    const ctx = qCanvas.getContext('2d');
    let P = [], W = 0, H = 0;
    function resize() { W = qCanvas.width = innerWidth; H = qCanvas.height = innerHeight; }
    function init() {
      P = [];
      const n = Math.min(100, Math.floor((W * H) / 12000));
      for (let i = 0; i < n; i++) {
        P.push({
          x: Math.random() * W, y: Math.random() * H,
          r: Math.random() * 1.5 + 0.3,
          vx: (Math.random() - 0.5) * 0.4,
          vy: (Math.random() - 0.5) * 0.4,
          a: Math.random() * 0.5 + 0.15
        });
      }
    }
    function frame() {
      ctx.clearRect(0, 0, W, H);
      for (let i = 0; i < P.length; i++) {
        const p = P[i];
        p.x += p.vx; p.y += p.vy;
        if (p.x < 0 || p.x > W) p.vx *= -1;
        if (p.y < 0 || p.y > H) p.vy *= -1;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(0,240,255,' + p.a + ')';
        ctx.fill();
      }
      for (let i = 0; i < P.length; i++) {
        for (let j = i + 1; j < P.length; j++) {
          const a = P[i], b = P[j];
          const dx = a.x - b.x, dy = a.y - b.y;
          const d = Math.sqrt(dx * dx + dy * dy);
          if (d < 100) {
            ctx.beginPath();
            ctx.moveTo(a.x, a.y);
            ctx.lineTo(b.x, b.y);
            ctx.strokeStyle = 'rgba(168,85,247,' + (0.14 * (1 - d / 100)) + ')';
            ctx.stroke();
          }
        }
      }
      requestAnimationFrame(frame);
    }
    resize(); init(); frame();
    addEventListener('resize', function () { resize(); init(); });
  } else if (qCanvas) qCanvas.style.display = 'none';

  /* ——— Hex field (quantum lattice look) ——— */
  const hCanvas = document.getElementById('hexCanvas');
  if (CFG.useHexField !== false && hCanvas) {
    const hctx = hCanvas.getContext('2d');
    let HW = 0, HH = 0, t0 = 0;
    const size = 22;
    function hresize() { HW = hCanvas.width = innerWidth; HH = hCanvas.height = innerHeight; }
    function hex(x, y, s, alpha) {
      hctx.beginPath();
      for (let i = 0; i < 6; i++) {
        const ang = Math.PI / 180 * (60 * i - 30);
        const px = x + s * Math.cos(ang);
        const py = y + s * Math.sin(ang);
        if (i === 0) hctx.moveTo(px, py); else hctx.lineTo(px, py);
      }
      hctx.closePath();
      hctx.strokeStyle = 'rgba(0,240,255,' + alpha + ')';
      hctx.stroke();
    }
    function hframe(ts) {
      t0 = ts * 0.00015;
      hctx.clearRect(0, 0, HW, HH);
      const h = size * Math.sqrt(3);
      const w = size * 2;
      const rows = Math.ceil(HH / h) + 2;
      const cols = Math.ceil(HW / (w * 0.75)) + 2;
      for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
          const x = c * w * 0.75;
          const y = r * h + (c % 2 ? h / 2 : 0);
          const wave = 0.04 + 0.06 * Math.sin(t0 + r * 0.3 + c * 0.25);
          hex(x, y, size * 0.45, wave);
        }
      }
      requestAnimationFrame(hframe);
    }
    hresize();
    requestAnimationFrame(hframe);
    addEventListener('resize', hresize);
  } else if (hCanvas) hCanvas.style.display = 'none';

  /* ——— Terminal ——— */
  function appendLine(text, cls) {
    const div = document.createElement('div');
    div.className = 'line' + (cls ? ' ' + cls : '');
    div.textContent = text;
    termBody.appendChild(div);
    termBody.scrollTop = termBody.scrollHeight;
  }

  function typeText(text, cls, speed) {
    speed = speed || 12;
    return new Promise(function (resolve) {
      typing = true;
      const div = document.createElement('div');
      div.className = 'line' + (cls ? ' ' + cls : '');
      const cursor = document.createElement('span');
      cursor.className = 'cursor';
      div.appendChild(cursor);
      termBody.appendChild(div);
      let i = 0;
      function step() {
        if (i < text.length) {
          div.insertBefore(document.createTextNode(text.charAt(i)), cursor);
          i++;
          termBody.scrollTop = termBody.scrollHeight;
          setTimeout(step, speed + Math.random() * 10);
        } else {
          cursor.remove();
          typing = false;
          resolve();
        }
      }
      step();
    });
  }

  function armIdleReveal() {
    if (idleTimer) clearTimeout(idleTimer);
    if (servicesRevealed) return;
    idleTimer = setTimeout(function () {
      if (!servicesRevealed && exchangeCount >= (CFG.minExchangesBeforeServices || 1)) {
        revealServices('idle');
      }
    }, (CFG.idleRevealSeconds || 12) * 1000);
  }

  function armAmbient() {
    if (ambientTimer) clearTimeout(ambientTimer);
    ambientTimer = setTimeout(async function () {
      if (pageVisible && !typing && document.visibilityState === 'visible' && I18N) {
        await typeText(I18N.ambientLine(sessionLang), 'dim', 10);
      }
      armAmbient();
    }, 6500 + Math.random() * 5500);
  }

  document.addEventListener('visibilitychange', function () {
    pageVisible = document.visibilityState === 'visible';
  });

  async function boot() {
    const mem = MEM.touchVisit();
    updateMemBadge(mem);
    sessionLang = mem.lang || 'en';
    if (I18N) {
      await typeText(I18N.t(sessionLang, 'boot1'), 'sys', 9);
      await typeText(I18N.t(sessionLang, 'boot2'), 'ok', 9);
      await typeText(I18N.t(sessionLang, 'boot3'), 'ok', 9);
      await typeText(MEM.greeting(mem), 'bot', 11);
      await typeText(I18N.t(sessionLang, 'ask'), 'dim', 10);
    } else {
      await typeText('[SYS] aaomsTech quantum shell online', 'sys', 10);
    }
    termInput && termInput.focus();
    armAmbient();
  }

  function updateMemBadge(mem) {
    if (!memBadge) return;
    memBadge.textContent = 'MEM · ' + (mem.lang || sessionLang || 'en').toUpperCase() + ' · ' + (mem.formality || 'NEUTRAL').toUpperCase() + ' · x' + (mem.exchanges || 0);
  }

  async function handleUser(raw) {
    if (typing) return;
    const q = (raw || '').trim();
    if (!q) return;
    if (termInput) termInput.value = '';
    sessionLang = I18N ? I18N.detect(q) : 'en';
    appendLine('$ ' + q, 'user');
    const mem = MEM.observe(q, sessionLang);
    updateMemBadge(mem);
    exchangeCount++;

    if (q.toLowerCase() === 'clear') {
      termBody.innerHTML = '';
      await typeText(I18N ? I18N.t(sessionLang, 'cleared') : '[OK] cleared', 'ok', 11);
      armIdleReveal();
      return;
    }

    const revealNow = (I18N && I18N.shouldReveal(q)) || (KB && KB.shouldRevealServices(q));
    let answer = null;
    if (I18N) {
      const topic = I18N.matchTopic(q);
      if (topic) answer = I18N.answerTopic(topic, sessionLang);
    }
    if (!answer && KB) answer = KB.answer(q, mem);
    if (!answer) answer = I18N ? I18N.t(sessionLang, 'fallback') : 'Rephrase with a concrete tech topic.';

    await typeText(answer, 'bot', 11);

    if (revealNow) {
      await typeText(I18N ? I18N.t(sessionLang, 'surfacing') : '[SYS] services…', 'sys', 11);
      revealServices('cmd');
    } else {
      armIdleReveal();
    }
  }

  function revealServices() {
    if (servicesRevealed) return;
    servicesRevealed = true;
    if (idleTimer) clearTimeout(idleTimer);
    if (!servicesSection) return;
    servicesSection.hidden = false;
    renderCards();
    const wa = document.getElementById('waLink');
    if (wa && CFG.whatsappNumber) {
      wa.href = 'https://wa.me/' + CFG.whatsappNumber + '?text=' + encodeURIComponent('Hi aaomsTech, project discussion');
    }
    const sub = document.getElementById('servicesSub');
    if (sub) {
      if (sessionLang === 'ne') sub.textContent = 'प्रश्न रोकियो — सेवा छान्नुहोस्';
      else if (sessionLang === 'hi') sub.textContent = 'सवाल रुके — सेवा चुनें';
    }
    servicesSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  function renderCards() {
    if (!cardsEl) return;
    cardsEl.innerHTML = '';
    services.forEach(function (s) {
      const card = document.createElement('article');
      card.className = 'card';
      card.innerHTML =
        '<div class="card-icon">' + s.icon + '</div>' +
        '<div class="card-name">' + s.name + '</div>' +
        '<div class="card-desc">' + s.desc + '</div>' +
        '<div class="card-tag">' + s.tag + '</div>' +
        '<div class="card-cta">SELECT → REQUEST</div>';
      card.addEventListener('click', function () {
        selectedService = s;
        openModal(s);
      });
      // 3D tilt
      card.addEventListener('mousemove', function (e) {
        const r = card.getBoundingClientRect();
        const x = (e.clientX - r.left) / r.width - 0.5;
        const y = (e.clientY - r.top) / r.height - 0.5;
        card.style.transform = 'perspective(700px) rotateY(' + (x * 10) + 'deg) rotateX(' + (-y * 10) + 'deg)';
      });
      card.addEventListener('mouseleave', function () { card.style.transform = ''; });
      cardsEl.appendChild(card);
    });
  }

  function submitInput() { handleUser(termInput ? termInput.value : ''); }
  if (termInput) {
    termInput.addEventListener('keydown', function (e) { if (e.key === 'Enter') submitInput(); });
    termInput.addEventListener('input', function () { if (idleTimer) clearTimeout(idleTimer); });
  }
  if (sendBtn) sendBtn.addEventListener('click', submitInput);

  const backdrop = document.getElementById('modalBackdrop');
  const form = document.getElementById('contactForm');
  const formStatus = document.getElementById('formStatus');

  function openModal(service) {
    selectedService = service || selectedService;
    document.getElementById('modalServiceName').textContent = selectedService ? selectedService.name : 'aaomsTech';
    document.getElementById('serviceId').value = selectedService ? selectedService.id : 'general';
    formStatus.textContent = '';
    backdrop.hidden = false;
  }
  function closeModal() { backdrop.hidden = true; }
  document.getElementById('openContactBtn') && document.getElementById('openContactBtn').addEventListener('click', function () { openModal(selectedService); });
  document.getElementById('modalClose') && document.getElementById('modalClose').addEventListener('click', closeModal);
  document.getElementById('modalCancel') && document.getElementById('modalCancel').addEventListener('click', closeModal);
  backdrop && backdrop.addEventListener('click', function (e) { if (e.target === backdrop) closeModal(); });

  if (form) {
    form.addEventListener('submit', async function (e) {
      e.preventDefault();
      const name = document.getElementById('name').value.trim();
      const contact = document.getElementById('contact').value.trim();
      const message = document.getElementById('message').value.trim();
      const serviceName = selectedService ? selectedService.name : 'General';
      if (!name || !contact || !message) {
        formStatus.textContent = 'Fill all fields.'; formStatus.className = 'form-status err'; return;
      }
      const payload = {
        name: name, contact: contact, message: message,
        serviceId: document.getElementById('serviceId').value,
        serviceName: serviceName, lang: sessionLang,
        source: 'aaomsTech-complete', timestamp: new Date().toISOString()
      };
      formStatus.textContent = 'Sending…';
      let sent = false;
      if (CFG.apiEndpoint) {
        try {
          const res = await fetch(CFG.apiEndpoint, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
          if (res.ok) sent = true;
        } catch (err) {}
      }
      if (!sent && CFG.fallback === 'whatsapp' && CFG.whatsappNumber) {
        window.open('https://wa.me/' + CFG.whatsappNumber + '?text=' + encodeURIComponent(
          'aaomsTech\n' + serviceName + '\n' + name + '\n' + contact + '\n' + message
        ), '_blank');
        sent = true;
      }
      formStatus.textContent = sent ? 'Request sent.' : 'Try WhatsApp.';
      formStatus.className = 'form-status ' + (sent ? 'ok' : 'err');
      if (sent) { form.reset(); setTimeout(closeModal, 1200); }
    });
  }

  boot();
})();
